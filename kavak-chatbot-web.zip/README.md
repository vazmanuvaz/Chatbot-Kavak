# Chatbot C-Level Kavak

Web app segura con login y análisis de Google Sheets usando LangChain.

1. Subí a GitHub
2. Deploy en Render
3. Seteá las variables de entorno:
  - `OPENAI_API_KEY`
  - `SECRET_KEY`

Luego ingresá con tu email y consultá sobre el funnel del negocio.